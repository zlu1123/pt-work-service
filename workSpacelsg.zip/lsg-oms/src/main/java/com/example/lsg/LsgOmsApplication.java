package com.example.lsg;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan(basePackages = {"com.lsg.oms.controller","com.lsg.oms.service"})
@MapperScan("com.lsg.oms.mapper")

public class LsgOmsApplication {

	public static void main(String[] args) {
		SpringApplication.run(LsgOmsApplication.class, args);
	}

}
