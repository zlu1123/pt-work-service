package com.lsg.oms.service;

import com.lsg.oms.exception.BusinessException;
import com.lsg.oms.model.Result;
import com.lsg.oms.vo.PositionApplyInfoVo;

public interface PositionManageService {
	
	Result insert(PositionApplyInfoVo positionApplyInfoVo,String openId);
	
	Result update(PositionApplyInfoVo positionApplyInfoVo,String openId);
	
	Result delete(PositionApplyInfoVo positionApplyInfoVo,String openId);
	
	Result page(PositionApplyInfoVo positionApplyInfoVo,String openId);
	
	Result applyList(PositionApplyInfoVo applyInfoVo,String openId);
	
	Result applyExam(PositionApplyInfoVo applyInfoVo,String openId) throws BusinessException;
	
	Result applyPush(PositionApplyInfoVo applyInfoVo,String openId);
}
