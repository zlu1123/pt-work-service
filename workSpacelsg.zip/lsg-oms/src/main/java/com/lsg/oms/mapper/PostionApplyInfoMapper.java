package com.lsg.oms.mapper;

import java.util.HashMap;


import com.lsg.oms.entity.OmsPostionApplyInfoPo;

import tk.mybatis.mapper.common.BaseMapper;

public interface PostionApplyInfoMapper extends BaseMapper<OmsPostionApplyInfoPo> {
	
	
	Integer updateExemStat(HashMap map);
	
    
}
