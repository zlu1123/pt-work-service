package com.lsg.oms.service.impl;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import com.lsg.oms.entity.OmsPostionApplyInfoPo;
import com.lsg.oms.exception.BusinessException;
import com.lsg.oms.mapper.PostionApplyInfoMapper;
import com.lsg.oms.model.Result;
import com.lsg.oms.service.PositionManageService;
import com.lsg.oms.vo.PositionApplyInfoVo;

@Service 
@Transactional(propagation = Propagation.REQUIRED, rollbackFor = {Exception.class})
public class PositionManageServiceServiceImpl implements PositionManageService{
	
	
	@Autowired
	private PostionApplyInfoMapper postionApplyInfoMapper;

	@Override
	public Result insert(PositionApplyInfoVo applyInfoVo, String openId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Result update(PositionApplyInfoVo applyInfoVo, String openId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Result delete(PositionApplyInfoVo applyInfoVo, String openId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Result page(PositionApplyInfoVo applyInfoVo, String openId) {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public Result applyExam(PositionApplyInfoVo applyInfoVo, String openId) throws BusinessException {
		
		//校验职位申请信息
		OmsPostionApplyInfoPo po = new OmsPostionApplyInfoPo();
		po.setPostionApplyId(applyInfoVo.getPostionApplyId());
		
		po = postionApplyInfoMapper.selectOne(po);
		
		if(null == po) {
			Result.error("职位申请信息不存在");
		}else {
			if(!"1".equals(po.getExemStat())) {
				Result.error("职位申请状态异常");
			}
		}
		
		//审核 职位申请
		exemPostionApply(applyInfoVo,openId);
		
		return Result.success();
	}

	private void exemPostionApply(PositionApplyInfoVo applyInfoVo, String openId) throws BusinessException {

		//获取userId
		String userId = openId;
		HashMap map = new HashMap<String,Object>();
		
		map.put("exemNo", userId);
		map.put("exemStat", "2");
		map.put("postionApplyId", applyInfoVo.getPostionApplyId());
		
		int num = postionApplyInfoMapper.updateExemStat(map);
		if(num == 0) {
			throw new BusinessException("数据库未更新");
		}
		
	}

	@Override
	public Result applyPush(PositionApplyInfoVo applyInfoVo, String openId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Result applyList(PositionApplyInfoVo applyInfoVo, String openId) {
		Integer pageNum = null;
        Integer pageSize = null;
        if(null!=applyInfoVo){
            pageNum = applyInfoVo.getPageNum();
            pageSize =applyInfoVo.getPageSize();
        }
		//根据查询条件查询职位申请列表
        OmsPostionApplyInfoPo po = new OmsPostionApplyInfoPo();
        po.setPostionId(applyInfoVo.getPostionId());
        po.setMerchId(applyInfoVo.getMerchId());
        po.setExemStat("1");
        
        List<OmsPostionApplyInfoPo> list = postionApplyInfoMapper.select(po);
        
        
		return Result.success(list);
	}
	
	




}
