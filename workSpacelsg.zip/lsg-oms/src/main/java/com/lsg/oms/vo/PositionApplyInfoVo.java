package com.lsg.oms.vo;

public class PositionApplyInfoVo {
	
	
  	private Integer pageNum;//页码

    private Integer pageSize;//页容量
    
	private String merchId;
	
	private String postionId;
	
	private String postionApplyId;

	public Integer getPageNum() {
		return pageNum;
	}

	public void setPageNum(Integer pageNum) {
		this.pageNum = pageNum;
	}

	public Integer getPageSize() {
		return pageSize;
	}

	public void setPageSize(Integer pageSize) {
		this.pageSize = pageSize;
	}

	public String getMerchId() {
		return merchId;
	}

	public void setMerchId(String merchId) {
		this.merchId = merchId;
	}

	public String getPostionId() {
		return postionId;
	}

	public void setPostionId(String postionId) {
		this.postionId = postionId;
	}

	public String getPostionApplyId() {
		return postionApplyId;
	}

	public void setPostionApplyId(String postionApplyId) {
		this.postionApplyId = postionApplyId;
	}
	
	
	
}
