package com.lsg.oms.vo;

public class PositionRepleaseVo {

}
