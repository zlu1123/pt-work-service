package com.lsg.wpa.service;




import com.lsg.wpa.model.Result;

public interface UserLoginService {
	
	Result getUserById(String id);
	
}	
