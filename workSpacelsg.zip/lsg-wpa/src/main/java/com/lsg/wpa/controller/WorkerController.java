package com.lsg.wpa.controller;

import javax.validation.Valid;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.lsg.wpa.model.Result;
import com.lsg.wpa.service.WorkerRoleService;
import com.lsg.wpa.vo.AttendanceRecordVo;
import com.lsg.wpa.vo.PostionInfoVo;
import com.lsg.wpa.vo.QueryPostionVo;
import com.lsg.wpa.vo.UserInfoVo;
import com.lsg.wpa.vo.WagePayRollVo;

@RestController
@RequestMapping("/worker" )
public class WorkerController {
	
	private Logger logger = LoggerFactory.getLogger(getClass());
	
	@Autowired
    private WorkerRoleService workerRoleService;	
	
	
	
	/**
	 *职位报名
	 * @throws Exception 
	 * */
	@ResponseBody
	@RequestMapping("/position/enRoll" )
    public Result enRoll(@RequestBody(required = false) @Valid PostionInfoVo postionInfoVo,
            @RequestHeader(value = "openId", required = true) String openId) throws Exception {
        
		//职位详报名
        return workerRoleService.enRoll(postionInfoVo, openId);

    }
	
	
	/**
	 *录用信息查询
	 * @throws Exception 
	 * */
	@ResponseBody
	@RequestMapping("/operation/disRoll" )
    public Result disRoll(@RequestBody(required = false) @Valid PostionInfoVo postionInfoVo,
            @RequestHeader(value = "openId", required = true) String openId) throws Exception {
        
		//职位详报名
        return workerRoleService.disRoll(postionInfoVo, openId);

    }
	
	/**
	 *结算信息
	 * */
	@ResponseBody
	@RequestMapping("/operation/queryBillInfo" )
    public Result queryBillInfo(@RequestHeader(value = "openId", required = true) String openId) {
        
		//职位详报名
        return workerRoleService.queryBillInfo(openId);

    }
	
	

	/**
	 *结算信息打卡记录
	 * */
	@ResponseBody
	@RequestMapping("/operation/queryClockIn" )
    public Result queryClockIn(@RequestHeader(value = "openId", required = true) String openId) {
        
		//结算信息查询
        return workerRoleService.queryClockIn(openId);

    }
	
	/**
	 *个人信息
	 * */
	@ResponseBody
	@RequestMapping("/mine/userInfo" )
    public Result userInfo(@RequestHeader(value = "openId", required = true) String openId) {
        
		//个人信息
        return workerRoleService.userInfo(openId);

    }
	
	
	/**
	 *个人信息维护
	 * */
	@ResponseBody
	@RequestMapping("/mine/userInfoMatn" )
    public Result userInfoMatn(@RequestBody(required = false) @Valid UserInfoVo userInfovo,
    		@RequestHeader(value = "openId", required = true) String openId) {
        
		//个人信息维护
        return workerRoleService.userInfoMatn(userInfovo,openId);

    }
	
	/**
	 *工资单
	 * */
	@ResponseBody
	@RequestMapping("/mine/payRollInfo" )
    public Result payRollInfo(@RequestHeader(value = "openId", required = true) String openId) {
        
		//工资单
        return workerRoleService.payRollInfo(openId);

    }
	
	
	/**
	 *工资发放
	 * */
	@ResponseBody
	@RequestMapping("/mine/GetPayRoll" )
    public Result getPayRoll(@RequestBody(required = false) @Valid WagePayRollVo wagePayRollVo,
    		@RequestHeader(value = "openId", required = true) String openId) {
        
		if(StringUtils.isBlank(wagePayRollVo.getPostionApplyId())) {
			Result.error("职位申请ID不能为空");
		}
		//工资发放
        try {
			return workerRoleService.getPayRoll(wagePayRollVo ,openId);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;

    }
	
	
	/**
	 *实名认证
	 * */
	@ResponseBody
	@RequestMapping("/mine/usrIdtfyCert" )
    public Result usrIdtfyCert(@RequestBody(required = true) @Valid String certNo,String custName,
    		@RequestHeader(value = "openId", required = true) String openId) {
        
		//工资发放
        return workerRoleService.usrIdtfyCert(certNo,custName,openId);

    }
	
	/**
	 *健康证认证
	 * */
	@ResponseBody
	@RequestMapping("/mine/healthCert" )
    public Result healthCert(@RequestBody(required = true) @Valid String fileImageAddr,
    		@RequestHeader(value = "openId", required = true) String openId) {
        
		//健康证认证
        return workerRoleService.healthCert(fileImageAddr,openId);

    }
	
	/**
	 *违约记录/违约处理
	 * */
	@ResponseBody
	@RequestMapping("/mine/defaultRecords" )
    public Result defaultRecords(@RequestBody(required = true) @Valid String optType,
    		@RequestHeader(value = "openId", required = true) String openId) {
        
		//违约记录/违约处理
        return workerRoleService.defaultRecords(optType,openId);

    }
	
	/**
	 *签到/签退
	 * */
	@ResponseBody
	@RequestMapping("/mine/clockInOrSignOut" )
    public Result clockInOrSignOut(@RequestBody(required = true) @Valid AttendanceRecordVo attendanceRecordVo,
    		@RequestHeader(value = "openId", required = true) String openId) {
        
		//违约记录/违约处理
        return workerRoleService.clockInOrSignOut(attendanceRecordVo,openId);

    }
	
	
}
