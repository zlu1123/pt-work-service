package com.lsg.wpa.vo;

public class PostionInfoVo {
	
	private String merchId;
	
	private String postionId;
	
	private String postionApplyId;

	public String getMerchId() {
		return merchId;
	}

	public void setMerchId(String merchId) {
		this.merchId = merchId;
	}

	public String getPostionId() {
		return postionId;
	}

	public void setPostionId(String postionId) {
		this.postionId = postionId;
	}

	public String getPostionApplyId() {
		return postionApplyId;
	}

	public void setPostionApplyId(String postionApplyId) {
		this.postionApplyId = postionApplyId;
	}
	
	
}
