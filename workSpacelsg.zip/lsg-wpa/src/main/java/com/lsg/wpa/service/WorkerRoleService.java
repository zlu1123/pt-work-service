package com.lsg.wpa.service;

import com.lsg.wpa.model.Result;
import com.lsg.wpa.vo.AttendanceRecordVo;
import com.lsg.wpa.vo.PostionInfoVo;
import com.lsg.wpa.vo.UserInfoVo;
import com.lsg.wpa.vo.WagePayRollVo;

public interface WorkerRoleService {
	
	Result enRoll(PostionInfoVo postionInfoVo,String openId) throws Exception;
	
	Result queryEmployInfo(String openId);
	
	Result disRoll(PostionInfoVo postionInfoVo,String openId) throws Exception;
	
	Result queryBillInfo(String openId);
	
	Result queryClockIn(String openId);
	
	Result userInfo(String openId);
	
	Result userInfoMatn(UserInfoVo userInfovo,String openId);
	
	Result payRollInfo(String openId);
	
	Result getPayRoll(WagePayRollVo wagePayRollVo,String openId)throws Exception;
	
	Result usrIdtfyCert(String certNo,String custName,String openId);
	
	Result healthCert(String fileImageAddr,String openId);
	
	Result defaultRecords(String optType,String openId);
	
	Result clockInOrSignOut(AttendanceRecordVo attendanceRecordVo,String openId);
}	
