package com.lsg.wpa.vo;

public class WagePayRollVo {
	
	private String postionApplyId;
	
	private String payType;

	public String getPostionApplyId() {
		return postionApplyId;
	}

	public void setPostionApplyId(String postionApplyId) {
		this.postionApplyId = postionApplyId;
	}

	public String getPayType() {
		return payType;
	}

	public void setPayType(String payType) {
		this.payType = payType;
	}

	
	
}
