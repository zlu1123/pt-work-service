package com.lsg.wpa.vo;

public class WechatPayVo {
	
	private String  tranCode;

	public String getTranCode() {
		return tranCode;
	}

	public void setTranCode(String tranCode) {
		this.tranCode = tranCode;
	}
	
	
	
}
