package com.lsg.wpa.mapper;



import com.lsg.wpa.entity.WpaUserInfo;

import tk.mybatis.mapper.common.BaseMapper;

public interface UserInfoMapper extends BaseMapper<WpaUserInfo> {
	
	 /**
     * 条件查询数据
     * @param userQueryVo
     * @return
     */
    
    WpaUserInfo selectOne(String openId);
	
}
