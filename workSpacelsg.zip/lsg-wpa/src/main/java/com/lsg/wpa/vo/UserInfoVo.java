package com.lsg.wpa.vo;

public class UserInfoVo {
	
	private String postionApplyId;

	public String getPostionApplyId() {
		return postionApplyId;
	}

	public void setPostionApplyId(String postionApplyId) {
		this.postionApplyId = postionApplyId;
	}
	
	
}
