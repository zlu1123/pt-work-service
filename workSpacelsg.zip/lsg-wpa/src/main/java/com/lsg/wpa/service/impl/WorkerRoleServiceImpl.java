package com.lsg.wpa.service.impl;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import com.lsg.utils.wechat.RSAUtils;
import com.lsg.wechatPay.WeiXinUtil;
import com.lsg.wpa.entity.OmsPostionApplyInfoPo;
import com.lsg.wpa.exception.BusinessException;
import com.lsg.wpa.mapper.PostionApplyInfoMapper;
import com.lsg.wpa.model.Result;
import com.lsg.wpa.service.WorkerRoleService;
import com.lsg.wpa.vo.AttendanceRecordVo;
import com.lsg.wpa.vo.PostionInfoVo;
import com.lsg.wpa.vo.UserInfoVo;
import com.lsg.wpa.vo.WagePayRollVo;

@Service 
@Transactional(propagation = Propagation.REQUIRED, rollbackFor = {Exception.class})
public class WorkerRoleServiceImpl implements WorkerRoleService{
	
	
	@Autowired
	private PostionApplyInfoMapper postionApplyInfoMapper;
	



	
	@Override
	public Result enRoll(PostionInfoVo postionInfoVo, String openId) throws Exception {
		
		//通过token获取UserId
		String userId = openId;
		
		//参数检查
		paramCheck(postionInfoVo);
		
		//查询是否有其他报名
		OmsPostionApplyInfoPo po = new OmsPostionApplyInfoPo();
		
		po.setApplyUserId(userId);
		po.setMerchId(po.getMerchId());
		po.setPostionId(po.getPostionId());
		po = postionApplyInfoMapper.selectOne(po);
		
		if(null!=po) {
			return Result.error("您已经申请了该职位");
		}
//		List<OmsPostionApplyInfoPo> list  = postionApplyInfoMapper.select(po);
//		
//		if(null != list && list.size() > 0) {
//			for(OmsPostionApplyInfoPo po1 : list) {
//				 //判断是否存在已录用信息
//				 if("3".equals(po1.getExemStat())) {
//					 return Result.error("您处于录用状态");
//				 }
//				 //同一职位同一公司 职能报名一次
//				 if(postionInfoVo.getPostionId().equals(po1.getPostionId())) {
//					 if(postionInfoVo.getMerchId().equals(po1.getMerchId())) {
//						 return Result.error("您在此公司，已经申请了这个职位了");
//					 }
//				 }
//			}
//		}
		//登记务工人员报名信息
		insertPostionApplyInfo(postionInfoVo,userId);
		
		return Result.success("00000000");
	}

	private String creatsPostionApplyId(PostionInfoVo postionInfoVo, String userId) {
		
		String time = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss"));
		String postionApplyId = time+postionInfoVo.getMerchId()+postionInfoVo.getPostionId();
		
		return postionApplyId;
	}

	private void insertPostionApplyInfo(PostionInfoVo postionInfoVo,String userId) {
		
		//生成职位申请ID
		String postionApplyId = creatsPostionApplyId(postionInfoVo,userId);
		
		OmsPostionApplyInfoPo po = new OmsPostionApplyInfoPo();
		
		po.setApplyUserId(userId);
		po.setPostionId(postionInfoVo.getPostionId());
		po.setMerchId(postionInfoVo.getMerchId());
		po.setPostionApplyId(postionApplyId);
		po.setExemStat("1");
		po.setCreateTime(new Date());
		po.setModifyTime(new Date());
		
		postionApplyInfoMapper.insert(po);
		
	}


	private Result paramCheck(PostionInfoVo postionInfoVo) {
		String merchId  = postionInfoVo.getMerchId();
		
		String postionId = postionInfoVo.getPostionId();
		
		if(StringUtils.isEmpty(merchId)) {
			return Result.error("企业名称不能为空");
		}
		if(StringUtils.isEmpty(postionId)) {
			return Result.error("职位信息");
		}
		return null;
	}

	@Override
	public Result queryEmployInfo(String openId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Result disRoll(PostionInfoVo postionInfoVo, String openId) throws Exception{
		//通过token获取UserId
		String userId = openId;
		
		OmsPostionApplyInfoPo po = new OmsPostionApplyInfoPo();
		
		po.setPostionApplyId(po.getPostionApplyId());
		int num = postionApplyInfoMapper.delete(po);
		
		if(num != 1) {
			return Result.error("数据库删除数量不符");
		}
		//删除报名信息
		return Result.success();
	}

	@Override
	public Result queryBillInfo(String openId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Result queryClockIn(String openId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Result userInfo(String openId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Result userInfoMatn(UserInfoVo userInfovo, String openId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Result payRollInfo(String openId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Result usrIdtfyCert(String certNo, String custName, String openId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Result healthCert(String fileImageAddr, String openId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Result defaultRecords(String optType, String openId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Result clockInOrSignOut(AttendanceRecordVo attendanceRecordVo, String openId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Result getPayRoll(WagePayRollVo wagePayRollVo, String openId) throws BusinessException {
		
		//1：微信转账
		if("1".equals(wagePayRollVo.getPayType())) {
			
		}
		//:2：账号转账
		else if ("2".equals(wagePayRollVo.getPayType())) {
			Map<String,String> map = new HashMap<String,String>();
			RSAUtils rsaUtils = new RSAUtils();
			try {
				WeiXinUtil weiXinUtil = new WeiXinUtil();
				weiXinUtil.wxCashBank(openId, openId, openId, openId, null, openId, openId);
//				map.put("mch_id", "1305638280");
//				map.put("partner_trade_no", "mch_id"+WXPayUtil.generateNonceStr());
//				map.put("nonce_str", WXPayUtil.generateNonceStr());
//				map.put("enc_bank_no", rsaUtils.encryptData("6226200107123722"));
//				map.put("enc_bank_no", rsaUtils.encryptData("张三"));
//				map.put("bank_code", "1006");
//				map.put("amount", "1");
//				map.put("desc", "转账");
				
				
//				map.put("sign", WXPayUtil.generateSignature(map, map.get("mch_id"), WXPayConfig.SIGN_TYPE));
//				String xmlWithdrawInfo = wxWithdrawTools.getXMLStringForObj(map);
//		        String response = wxWithdrawTools.postParamesForUrl(xmlWithdrawInfo, WXWithdrawTools.WITHDRAW);
//		        System.out.println(response);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}else {
			throw new BusinessException ("不支持其他类型转账");
		}
		
		
		
		
		
		return null;
	}




}
