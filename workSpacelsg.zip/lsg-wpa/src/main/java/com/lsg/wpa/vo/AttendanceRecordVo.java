package com.lsg.wpa.vo;

public class AttendanceRecordVo {

}
