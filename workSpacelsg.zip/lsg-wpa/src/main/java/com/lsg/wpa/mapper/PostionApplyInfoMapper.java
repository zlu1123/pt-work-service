package com.lsg.wpa.mapper;

import com.lsg.wpa.entity.OmsPostionApplyInfoPo;

import tk.mybatis.mapper.common.BaseMapper;

public interface PostionApplyInfoMapper extends BaseMapper<OmsPostionApplyInfoPo> {

	 /**
     * 条件查询数据
     * @param userQueryVo
     * @return
     */
    
}
